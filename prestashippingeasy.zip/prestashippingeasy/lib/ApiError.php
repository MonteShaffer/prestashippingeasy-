<?php

class ShippingEasy_ApiError extends ShippingEasy_Error
{
}
