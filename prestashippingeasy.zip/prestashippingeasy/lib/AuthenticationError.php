<?php

class ShippingEasy_AuthenticationError extends ShippingEasy_Error
{
}
